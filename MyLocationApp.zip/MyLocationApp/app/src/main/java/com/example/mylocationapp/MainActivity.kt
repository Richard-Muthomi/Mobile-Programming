package com.example.mylocationapp

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.NonNull
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.app.ActivityCompat
import androidx.lifecycle.ReportFragment.Companion.reportFragment
import com.example.mylocationapp.ui.theme.MyLocationAppTheme

public class MainActivity : ComponentActivity() {

    private FusedLocationProviderClient locationClient;
    private final int REQUEST_PERMISSION_FINE_LOCATION= 1;
    private TextView txtLocation;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) ;

        locationClient=LocationServices.getfusedLocationProviderClient(activity:this);
        txtLocation= ((TextView) findviewById(R.id.txtLocation));

        if (ActivityCompat.checkSelfPermission(context:this,
            android.Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQUEST_PERMISSION_FINE_LOCATION);
        }
        else{
            showlocation();
        }
        @SuppressLint("MissingPermission");
        private void showLocation(){
            locationClient.getLastlocation().
            addOnSuccessListener(activity:this,new OnSuccessListener<Location>(){
            @Override
            public void onSuccess(Location location){
                if(location != null) {
                    txtLocation.setText("Current location is :\n" + location.getLatitude()
                            + "\nlon" +location.getLongitude());
                }
            }
        }
        }
    }
        locationClient.getLastLocation().
                add
        @Override
        public void onComplete(@NonNull Task<Location>task){
           if
    }
    }

